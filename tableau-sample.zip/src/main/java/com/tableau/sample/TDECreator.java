package com.tableau.sample;

import com.tableausoftware.TableauException;
import com.tableausoftware.common.Collation;
import com.tableausoftware.common.Type;
import com.tableausoftware.extract.*;

/**
 * Sample to create TDE
 */
public class TDECreator {

  // Define the table's schema
  private TableDefinition createTableDefinition() throws TableauException {

    TableDefinition tableDef = new TableDefinition();
    tableDef.setDefaultCollation(Collation.EN_US);

    tableDef.addColumn("Product", Type.CHAR_STRING);
    tableDef.addColumn("Quantity", Type.INTEGER);
    tableDef.addColumn("Price", Type.INTEGER);

    return tableDef;
  }

  private void insertSampleData(Table table) throws TableauException {
    TableDefinition tableDef = table.getTableDefinition();
    Row row = new Row(tableDef);

    for ( int i = 1; i <= 10; ++i ) {
      row.setCharString(0, "Office No" + i);
      row.setInteger(1, i + 1);
      row.setInteger(2, 10 * i);

      table.insert(row);
    }
  }

  public String createSampleExtract() {
    String tde = "sample-tde.tde";
    try {
      // Initialize Tableau Extract API
      ExtractAPI.initialize();

      try (Extract extract = new Extract(tde)) {

        Table table;
        if (!extract.hasTable("Extract")) {
          // Table does not exist; create it
          TableDefinition tableDef = createTableDefinition();
          table = extract.addTable("Extract", tableDef);
        } else {
          // Open an existing table to add more rows
          table = extract.openTable("Extract");
        }

        insertSampleData(table);
      }

      // Clean up Tableau Extract API
      ExtractAPI.cleanup();
    } catch (Exception e) {
      e.printStackTrace();
    }

    return tde;
  }

}
